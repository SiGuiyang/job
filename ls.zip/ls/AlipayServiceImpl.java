package quick.pager.pay.service.repository.pay;

import cn.hutool.core.date.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import quick.pager.common.constants.Constants;
import quick.pager.common.pay.client.IClient;
import quick.pager.common.pay.client.PayClient;
import quick.pager.common.pay.request.AlipayAppRequest;
import quick.pager.common.pay.request.AlipayWapRequest;
import quick.pager.common.pay.request.AlipayWebRequest;
import quick.pager.common.resp.Response;
import quick.pager.pay.dto.PayDto;
import quick.pager.pay.model.PayChannel;
import quick.pager.pay.service.pay.AlipayService;

import java.math.BigDecimal;
import java.util.Date;

@Service
public class AlipayServiceImpl extends BaseServiceImpl implements AlipayService {

    private IClient client = new PayClient();

    @Override
    public Response payH5(PayDto dto) {
        AlipayWapRequest wapRequest = new AlipayWapRequest();
        PayChannel payChannel = this.queryCurrentPayChannel(dto.getPayType());
        wapRequest.setBody(dto.getBody());
        wapRequest.setOutTradeNo(dto.getOrderCode());
        wapRequest.setTotalAmount(new BigDecimal(dto.getPayAmount()));
        wapRequest.setAppId(payChannel.getAppId());
        wapRequest.setSubject("Pager支付");
        wapRequest.setNotifyUrl(this.getNotifyUrl(Constants.Keys.ALIPAY_NOTIFY_URL));
        wapRequest.setSignType(Constants.SignType.RSA2.name());
        wapRequest.setTimestamp(DateUtil.formatDateTime(new Date()));
        return client.wapPay(wapRequest);
    }

    @Override
    public Response payApp(PayDto dto) {
        AlipayAppRequest appRequest = new AlipayAppRequest();

        PayChannel payChannel = this.queryCurrentPayChannel(dto.getPayType());


        appRequest.setBody(dto.getBody());
        appRequest.setOutTradeNo(dto.getOrderCode());
        appRequest.setAppId(payChannel.getAppId());
        appRequest.setNotifyUrl(this.getNotifyUrl(Constants.Keys.ALIPAY_NOTIFY_URL));
        appRequest.setTotalAmount(new BigDecimal(dto.getPayAmount()));
        appRequest.setSignType(Constants.SignType.RSA2.name());
        appRequest.setTimestamp(DateUtil.formatDateTime(new Date()));
        appRequest.setVersion("1.0");
        appRequest.setSubject("Pager支付");

        return client.appPay(appRequest);
    }

    @Override
    public Response payWeb(PayDto dto) {
        return null;
    }

    @Override
    public Response payScan(PayDto dto) {
       return null;
    }
}
