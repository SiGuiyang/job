package quick.pager.common.pay.client;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.domain.AlipayTradeCloseModel;
import com.alipay.api.domain.AlipayTradeFastpayRefundQueryModel;
import com.alipay.api.domain.AlipayTradePayModel;
import com.alipay.api.domain.AlipayTradeQueryModel;
import com.alipay.api.domain.AlipayTradeRefundModel;
import com.alipay.api.domain.AlipayTradeWapPayModel;
import com.alipay.api.request.AlipayTradeAppPayRequest;
import com.alipay.api.request.AlipayTradeCloseRequest;
import com.alipay.api.request.AlipayTradeFastpayRefundQueryRequest;
import com.alipay.api.request.AlipayTradePayRequest;
import com.alipay.api.request.AlipayTradeQueryRequest;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.request.AlipayTradeWapPayRequest;
import com.alipay.api.response.AlipayTradeAppPayResponse;
import com.alipay.api.response.AlipayTradeCloseResponse;
import com.alipay.api.response.AlipayTradeFastpayRefundQueryResponse;
import com.alipay.api.response.AlipayTradePayResponse;
import com.alipay.api.response.AlipayTradeQueryResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.alipay.api.response.AlipayTradeWapPayResponse;
import quick.pager.common.constants.RespConstants;
import quick.pager.common.pay.request.AlipayAppRequest;
import quick.pager.common.pay.request.AlipayCloseRequest;
import quick.pager.common.pay.request.AlipayQueryRequest;
import quick.pager.common.pay.request.AlipayRefundQueryRequest;
import quick.pager.common.pay.request.AlipayRefundRequest;
import quick.pager.common.pay.request.AlipayRequest;
import quick.pager.common.pay.request.AlipayWapRequest;
import quick.pager.common.resp.Response;

import java.util.HashMap;
import java.util.Map;

/**
 * 支付宝支付
 */
public class PayClient extends BasePayClient {

    @Override
    public Response payOrder(IRequest request) {

        Response resp = new Response();
        if (request instanceof AlipayRequest) {
            AlipayRequest orderRequest = (AlipayRequest) request;
            AlipayClient client = new DefaultAlipayClient(orderRequest.getRequestUrl(), orderRequest.getAppId(), orderRequest.getPrivateKey(), "json", "UTF-8", orderRequest.getAlipayPublicKey(), orderRequest.getSignType());
            // 参数组装到第三方支付宝
            AlipayTradePayModel alipayTradePayModel = new AlipayTradePayModel();
            alipayTradePayModel.setAuthCode(orderRequest.getAuthCode());
            alipayTradePayModel.setBody(orderRequest.getBody());
            alipayTradePayModel.setBuyerId(orderRequest.getBuyerId());
            alipayTradePayModel.setOperatorId(orderRequest.getOperatorId());
            alipayTradePayModel.setOutTradeNo(orderRequest.getOutTradeNo());
            alipayTradePayModel.setTotalAmount(orderRequest.getTotalAmount().toPlainString());
            alipayTradePayModel.setSubject(orderRequest.getSubject());
            alipayTradePayModel.setTransCurrency(orderRequest.getTransCurrency());
            alipayTradePayModel.setSettleCurrency(orderRequest.getSettleCurrency());
            alipayTradePayModel.setTerminalId(orderRequest.getTerminalId());
            alipayTradePayModel.setTimeoutExpress(orderRequest.getTimeoutExpress());
            alipayTradePayModel.setAuthConfirmMode(orderRequest.getAuthConfirmMode());
            alipayTradePayModel.setTerminalParams(orderRequest.getTerminalParams());
            alipayTradePayModel.setSellerId(orderRequest.getSellerId());
            alipayTradePayModel.setScene(orderRequest.getScene());
            alipayTradePayModel.setProductCode(orderRequest.getProductCode());

            AlipayTradePayRequest alipayTradePayRequest = new AlipayTradePayRequest();
            alipayTradePayRequest.setBizModel(alipayTradePayModel);
            alipayTradePayRequest.setNotifyUrl(orderRequest.getNotifyUrl());
            alipayTradePayRequest.setNeedEncrypt(true);
            alipayTradePayRequest.setReturnUrl(orderRequest.getReturnUrl());

            try {
                // 请求支付
                AlipayTradePayResponse response = client.execute(alipayTradePayRequest);
                if (response.isSuccess()) {
                    resp.setCode(RespConstants.SUCCESS.code);
                    resp.setMsg(RespConstants.SUCCESS.msg);
                    Map<String, String> result = new HashMap<>();
                    result.put("tradeNo", response.getTradeNo());
                    result.put("outTradeNo", response.getOutTradeNo());
                    result.put("openId", response.getOpenId());
                    resp.setData(result);
                } else {
                    resp.setCode(RespConstants.ALIPAY_REQUEST_RESPONSE.code);
                    resp.setMsg(RespConstants.ALIPAY_REQUEST_RESPONSE.msg);
                }
            } catch (AlipayApiException e) {
                e.printStackTrace();
                resp.setCode(RespConstants.ALIPAY_REQUEST_EXCEPTION.code);
                resp.setMsg(RespConstants.ALIPAY_REQUEST_EXCEPTION.msg);
            }

        } else {
            resp.setCode(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }

    @Override
    public Response closeOrder(IRequest request) {
        Response resp = new Response();
        if (request instanceof AlipayCloseRequest) {
            AlipayCloseRequest closeRequest = (AlipayCloseRequest) request;
            AlipayClient client = new DefaultAlipayClient(closeRequest.getRequestUrl(), closeRequest.getAppId(), closeRequest.getPrivateKey(), "json", "UTF-8", closeRequest.getAlipayPublicKey(), closeRequest.getSignType());

            AlipayTradeCloseModel alipayTradeCloseModel = new AlipayTradeCloseModel();
            alipayTradeCloseModel.setOperatorId(closeRequest.getOperatorId());
            alipayTradeCloseModel.setOutTradeNo(closeRequest.getOutTradeNo());
            alipayTradeCloseModel.setTradeNo(closeRequest.getTradeNo());

            AlipayTradeCloseRequest alipayTradeCloseRequest = new AlipayTradeCloseRequest();
            alipayTradeCloseRequest.setBizModel(alipayTradeCloseModel);
            alipayTradeCloseRequest.setNeedEncrypt(true);
            alipayTradeCloseRequest.setNotifyUrl(closeRequest.getNotifyUrl());
            alipayTradeCloseRequest.setReturnUrl(closeRequest.getReturnUrl());

            try {
                AlipayTradeCloseResponse response = client.execute(alipayTradeCloseRequest);

                if (response.isSuccess()) {
                    resp.setCode(RespConstants.SUCCESS.code);
                    resp.setMsg(RespConstants.SUCCESS.msg);
                    Map<String, String> result = new HashMap<>();
                    result.put("tradeNo", response.getTradeNo());
                    result.put("outTradeNo", response.getOutTradeNo());
                    resp.setData(result);
                } else {
                    resp.setCode(RespConstants.ALIPAY_REQUEST_RESPONSE.code);
                    resp.setMsg(RespConstants.ALIPAY_REQUEST_RESPONSE.msg);
                }
            } catch (AlipayApiException e) {
                e.printStackTrace();
                resp.setCode(RespConstants.ALIPAY_REQUEST_EXCEPTION.code);
                resp.setMsg(RespConstants.ALIPAY_REQUEST_EXCEPTION.msg);
            }

        } else {
            resp.setCode(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }

    @Override
    public Response refundOrder(IRequest request) {
        Response resp = new Response();
        if (request instanceof AlipayRefundRequest) {
            AlipayRefundRequest refundRequest = (AlipayRefundRequest) request;
            AlipayClient client = new DefaultAlipayClient(refundRequest.getRequestUrl(), refundRequest.getAppId(), refundRequest.getPrivateKey(), "json", "UTF-8", refundRequest.getAlipayPublicKey(), refundRequest.getSignType());

            AlipayTradeRefundModel alipayTradeRefundModel = new AlipayTradeRefundModel();

            alipayTradeRefundModel.setOutTradeNo(refundRequest.getOutTradeNo());
            alipayTradeRefundModel.setTradeNo(refundRequest.getTradeNo());
            alipayTradeRefundModel.setOutRequestNo(refundRequest.getOutRequestNo());
            alipayTradeRefundModel.setOperatorId(refundRequest.getOperatorId());
            alipayTradeRefundModel.setRefundAmount(refundRequest.getRefundAmount().toPlainString());
            alipayTradeRefundModel.setRefundCurrency(refundRequest.getRefundCurrency());
            alipayTradeRefundModel.setRefundReason(refundRequest.getRefundReason());
            alipayTradeRefundModel.setTerminalId(refundRequest.getTerminalId());
            alipayTradeRefundModel.setStoreId(refundRequest.getStoreId());

            AlipayTradeRefundRequest alipayTradeRefundRequest = new AlipayTradeRefundRequest();

            alipayTradeRefundRequest.setBizModel(alipayTradeRefundModel);
            alipayTradeRefundRequest.setNeedEncrypt(true);
            alipayTradeRefundRequest.setNotifyUrl(refundRequest.getNotifyUrl());
            alipayTradeRefundRequest.setReturnUrl(refundRequest.getReturnUrl());

            try {
                AlipayTradeRefundResponse response = client.execute(alipayTradeRefundRequest);

                if (response.isSuccess()) {
                    resp.setCode(RespConstants.SUCCESS.code);
                    resp.setMsg(RespConstants.SUCCESS.msg);
                    Map<String, String> result = new HashMap<>();
                    result.put("tradeNo", response.getTradeNo());
                    result.put("outTradeNo", response.getOutTradeNo());
                    result.put("amount", response.getRefundFee());
                    resp.setData(result);
                } else {
                    resp.setCode(RespConstants.ALIPAY_REQUEST_RESPONSE.code);
                    resp.setMsg(RespConstants.ALIPAY_REQUEST_RESPONSE.msg);
                }
            } catch (AlipayApiException e) {
                e.printStackTrace();
                resp.setCode(RespConstants.ALIPAY_REQUEST_EXCEPTION.code);
                resp.setMsg(RespConstants.ALIPAY_REQUEST_EXCEPTION.msg);
            }

        } else {
            resp.setCode(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }

    @Override
    public Response queryPayOrder(IRequest request) {
        Response resp = new Response();
        if (request instanceof AlipayQueryRequest) {
            AlipayQueryRequest queryRequest = (AlipayQueryRequest) request;
            AlipayClient client = new DefaultAlipayClient(queryRequest.getRequestUrl(), queryRequest.getAppId(), queryRequest.getPrivateKey(), "json", "UTF-8", queryRequest.getAlipayPublicKey(), queryRequest.getSignType());

            AlipayTradeQueryModel alipayTradeQueryModel = new AlipayTradeQueryModel();

            alipayTradeQueryModel.setOutTradeNo(queryRequest.getOutTradeNo());
            alipayTradeQueryModel.setTradeNo(queryRequest.getTradeNo());

            AlipayTradeQueryRequest alipayTradeQueryRequest = new AlipayTradeQueryRequest();

            alipayTradeQueryRequest.setBizModel(alipayTradeQueryModel);
            alipayTradeQueryRequest.setNeedEncrypt(true);
            alipayTradeQueryRequest.setNotifyUrl(queryRequest.getNotifyUrl());
            alipayTradeQueryRequest.setReturnUrl(queryRequest.getReturnUrl());

            try {
                AlipayTradeQueryResponse response = client.execute(alipayTradeQueryRequest);

                if (response.isSuccess()) {
                    resp.setCode(RespConstants.SUCCESS.code);
                    resp.setMsg(RespConstants.SUCCESS.msg);
                    Map<String, String> result = new HashMap<>();
                    result.put("tradeNo", response.getTradeNo());
                    result.put("outTradeNo", response.getOutTradeNo());
                    result.put("totalAmount", response.getTotalAmount());
                    result.put("payAmount", response.getPayAmount());
                    resp.setData(result);
                } else {
                    resp.setCode(RespConstants.ALIPAY_REQUEST_RESPONSE.code);
                    resp.setMsg(RespConstants.ALIPAY_REQUEST_RESPONSE.msg);
                }
            } catch (AlipayApiException e) {
                e.printStackTrace();
                resp.setCode(RespConstants.ALIPAY_REQUEST_EXCEPTION.code);
                resp.setMsg(RespConstants.ALIPAY_REQUEST_EXCEPTION.msg);
            }

        } else {
            resp.setCode(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }

    @Override
    public Response queryRefundOrder(IRequest request) {
        Response resp = new Response();
        if (request instanceof AlipayRefundQueryRequest) {
            AlipayRefundQueryRequest refundQueryRequest = (AlipayRefundQueryRequest) request;
            AlipayClient client = new DefaultAlipayClient(refundQueryRequest.getRequestUrl(), refundQueryRequest.getAppId(), refundQueryRequest.getPrivateKey(), "json", "UTF-8", refundQueryRequest.getAlipayPublicKey(), refundQueryRequest.getSignType());

            AlipayTradeFastpayRefundQueryModel alipayTradeFastpayRefundQueryModel = new AlipayTradeFastpayRefundQueryModel();

            alipayTradeFastpayRefundQueryModel.setTradeNo(refundQueryRequest.getTradeNo());
            alipayTradeFastpayRefundQueryModel.setOutTradeNo(refundQueryRequest.getOutTradeNo());
            alipayTradeFastpayRefundQueryModel.setOutRequestNo(refundQueryRequest.getOutRequestNo());

            AlipayTradeFastpayRefundQueryRequest alipayTradeFastpayRefundQueryRequest = new AlipayTradeFastpayRefundQueryRequest();
            alipayTradeFastpayRefundQueryRequest.setBizModel(alipayTradeFastpayRefundQueryModel);
            alipayTradeFastpayRefundQueryRequest.setNeedEncrypt(true);
            alipayTradeFastpayRefundQueryRequest.setNotifyUrl(refundQueryRequest.getNotifyUrl());
            alipayTradeFastpayRefundQueryRequest.setReturnUrl(refundQueryRequest.getReturnUrl());

            try {
                AlipayTradeFastpayRefundQueryResponse response = client.execute(alipayTradeFastpayRefundQueryRequest);

                if (response.isSuccess()) {
                    resp.setCode(RespConstants.SUCCESS.code);
                    resp.setMsg(RespConstants.SUCCESS.msg);
                    Map<String, String> result = new HashMap<>();
                    result.put("tradeNo", response.getTradeNo());
                    result.put("outTradeNo", response.getOutTradeNo());
                    result.put("outRequestNo", response.getOutRequestNo());
                    result.put("refundReason", response.getRefundReason());
                    result.put("totalAmount", response.getTotalAmount());
                    result.put("refundAmount", response.getRefundAmount());
                    resp.setData(result);
                } else {
                    resp.setCode(RespConstants.ALIPAY_REQUEST_RESPONSE.code);
                    resp.setMsg(RespConstants.ALIPAY_REQUEST_RESPONSE.msg);
                }
            } catch (AlipayApiException e) {
                e.printStackTrace();
                resp.setCode(RespConstants.ALIPAY_REQUEST_EXCEPTION.code);
                resp.setMsg(RespConstants.ALIPAY_REQUEST_EXCEPTION.msg);
            }

        } else {
            resp.setCode(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }


    @Override
    public Response wapPay(IRequest request) {
        Response resp = new Response();
        if (request instanceof AlipayWapRequest) {
            AlipayWapRequest wapRequest = (AlipayWapRequest) request;
            AlipayClient client = new DefaultAlipayClient(wapRequest.getRequestUrl(), wapRequest.getAppId(), wapRequest.getPrivateKey(), "json", "UTF-8", wapRequest.getAlipayPublicKey(), wapRequest.getSignType());

            AlipayTradeWapPayModel alipayTradeWapPayModel = new AlipayTradeWapPayModel();
            alipayTradeWapPayModel.setBody(wapRequest.getBody());
            alipayTradeWapPayModel.setOutTradeNo(wapRequest.getOutTradeNo());
            alipayTradeWapPayModel.setTotalAmount(wapRequest.getTotalAmount().toPlainString());
            alipayTradeWapPayModel.setSubject(wapRequest.getSubject());
            alipayTradeWapPayModel.setProductCode(wapRequest.getProductCode());
            alipayTradeWapPayModel.setTimeoutExpress(wapRequest.getTimeoutExpress());
            //创建API对应的request
            AlipayTradeWapPayRequest alipayTradeWapPayRequest = new AlipayTradeWapPayRequest();
            alipayTradeWapPayRequest.setBizModel(alipayTradeWapPayModel);
            alipayTradeWapPayRequest.setNotifyUrl(wapRequest.getNotifyUrl());
            alipayTradeWapPayRequest.setReturnUrl(wapRequest.getReturnUrl());
            alipayTradeWapPayRequest.setNeedEncrypt(true);
            try {
                AlipayTradeWapPayResponse response = client.pageExecute(alipayTradeWapPayRequest);
                if (response.isSuccess()) {
                    resp.setCode(RespConstants.SUCCESS.code);
                    resp.setMsg(RespConstants.SUCCESS.msg);
                    Map<String, String> result = new HashMap<>();
                    result.put("payUrl", response.getBody());
                    resp.setData(result);
                }
            } catch (AlipayApiException e) {
                e.printStackTrace();
                resp.setCode(RespConstants.ALIPAY_REQUEST_EXCEPTION.code);
                resp.setMsg(RespConstants.ALIPAY_REQUEST_EXCEPTION.msg);
            }

        } else {
            resp.setCode(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }

    @Override
    public Response appPay(IRequest request) {
        Response resp = new Response();
        if (request instanceof AlipayAppRequest) {
            AlipayAppRequest appRequest = (AlipayAppRequest) request;
            AlipayClient client = new DefaultAlipayClient(appRequest.getRequestUrl(), appRequest.getAppId(), appRequest.getPrivateKey(), "json", "UTF-8", appRequest.getAlipayPublicKey(), appRequest.getSignType());

            AlipayTradeAppPayModel alipayTradeAppPayModel = new AlipayTradeAppPayModel();
            alipayTradeAppPayModel.setBody(appRequest.getBody());
            alipayTradeAppPayModel.setOutTradeNo(appRequest.getOutTradeNo());
            alipayTradeAppPayModel.setTotalAmount(appRequest.getTotalAmount().toPlainString());
            alipayTradeAppPayModel.setSubject(appRequest.getSubject());
            //创建API对应的request
            AlipayTradeAppPayRequest alipayTradeAppPayRequest = new AlipayTradeAppPayRequest();
            alipayTradeAppPayRequest.setBizModel(alipayTradeAppPayModel);
            alipayTradeAppPayRequest.setNotifyUrl(appRequest.getNotifyUrl());
            alipayTradeAppPayRequest.setReturnUrl(appRequest.getReturnUrl());
            alipayTradeAppPayRequest.setNeedEncrypt(true);
            try {
                AlipayTradeAppPayResponse response = client.sdkExecute(alipayTradeAppPayRequest);
                if (response.isSuccess()) {
                    resp.setCode(RespConstants.SUCCESS.code);
                    resp.setMsg(RespConstants.SUCCESS.msg);
                    Map<String, String> result = new HashMap<>();
                    result.put("payPrams", response.getBody());
                    resp.setData(result);
                }
            } catch (AlipayApiException e) {
                e.printStackTrace();
                resp.setCode(RespConstants.ALIPAY_REQUEST_EXCEPTION.code);
                resp.setMsg(RespConstants.ALIPAY_REQUEST_EXCEPTION.msg);
            }

        } else {
            resp.setCode(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.ALIPAY_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }

    @Override
    public Response webPay(IRequest request) {
        Response resp = new Response();


        return null;
    }
}
