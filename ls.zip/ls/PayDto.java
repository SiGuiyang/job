package quick.pager.pay.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@EqualsAndHashCode(callSuper = true)
@Data
@ToString
public class PayDto extends Dto {

    /**
     * 客户端真实ip地址
     */
    private String clientIp;
    /**
     * 跳转地址
     */
    private String jumpUrl;
    /**
     * 平台订单号<br />
     * 自身平台
     */
    private String orderCode;
}
