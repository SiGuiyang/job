package quick.pager.common.pay.client;

import quick.pager.common.pay.response.WeiXinBaseResponse;
import quick.pager.common.resp.Response;

/**
 * 顶级支付接口
 */
public interface IClient {
    /**
     * 微信所有请求都使用此接口
     *
     * @param request 请求入参对象
     * @param url     请求地址
     * @return 返回结果
     */
    WeiXinBaseResponse execute(IRequest request, String url, WeiXinBaseResponse response);

    /**
     * 统一下单
     *
     * @param request 请求入参对象
     */
    Response payOrder(IRequest request);

    /**
     * 关闭订单
     *
     * @param request 请求入参对象
     */
    Response closeOrder(IRequest request);

    /**
     * 退款
     *
     * @param request 请求入参对象
     */
    Response refundOrder(IRequest request);

    /**
     * 查询订单
     *
     * @param request 请求入参对象
     */
    Response queryPayOrder(IRequest request);

    /**
     * 查询退款订单
     *
     * @param request 请求入参对象
     */
    Response queryRefundOrder(IRequest request);

    /**
     * H5|手机网站支付
     *
     * @param request 请求入参对象
     */
    Response wapPay(IRequest request);

    /**
     * 电脑网站支付
     * @param request 请求入参对象
     */
    Response webPay(IRequest request);

    /**
     * 手机APP支付
     *
     * @param request 请求入参对象
     */
    Response appPay(IRequest request);
}
