package quick.pager.pay.service.pay;

import quick.pager.common.resp.Response;
import quick.pager.pay.dto.PayDto;
import quick.pager.pay.event.pay.AlipayEvent;
import quick.pager.pay.event.pay.WeiXinEvent;
import quick.pager.pay.request.PayRequest;
import quick.pager.pay.request.SubmitAlipayRequest;
import quick.pager.pay.request.SubmitWeiXinRequest;

/**
 * 支付服务
 */
public interface PayService {

    /**
     * 请求支付
     */
    Response submitOrder(PayRequest request);

    /**
     * 支付宝支付
     */
    Response payOrderAlipay(PayDto dto);

    /**
     * 微信支付
     */
    Response payOrderWeChatPay(PayDto dto);
}
