package quick.pager.pay.service.repository.pay;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import quick.pager.common.constants.Constants;
import quick.pager.common.constants.RespConstants;
import quick.pager.common.pay.client.IClient;
import quick.pager.common.pay.client.WeiXinPayClient;
import quick.pager.common.pay.request.WeiXinOrderRequest;
import quick.pager.common.resp.Response;
import quick.pager.common.utils.CodeUtils;
import quick.pager.common.utils.SignUtils;
import quick.pager.pay.dto.PayDto;
import quick.pager.pay.model.PayChannel;
import quick.pager.pay.service.pay.WeiXinService;

import java.io.Serializable;
import java.util.Map;
import java.util.UUID;


@Service
@Slf4j
public class WeiXinServiceImpl extends BaseServiceImpl implements WeiXinService {

    private IClient client = new WeiXinPayClient();



    @Override
    public Response payH5(PayDto dto) {
        log.info("微信H5支付，入参 = {}",dto);
        WeiXinOrderRequest orderRequest = new WeiXinOrderRequest();
        PayChannel payChannel = this.queryCurrentPayChannel(dto.getPayType());

        if (ObjectUtils.isEmpty(payChannel)) {
            return new Response(RespConstants.UNKNOWN_CHANNEL.code,RespConstants.UNKNOWN_CHANNEL.msg);
        }

        String nonceStr = UUID.randomUUID().toString();

        SceneInfo sceneInfo = new SceneInfo();
        SceneInfoContent content = new SceneInfoContent();
        content.setType("Wap");
        content.setWap_url("https://pay.qq.com");
        content.setWap_name("腾讯充值");
        sceneInfo.setH5_info(content);
        // 生成微信H5支付签名
        String sign = generateSign(payChannel,dto,nonceStr,Constants.TradeType.H5_TRADE_TYPE,"", JSON.toJSONString(sceneInfo));

        orderRequest.setAppId(payChannel.getAppId());
        orderRequest.setMchId(payChannel.getMchId());
        orderRequest.setNonceStr(nonceStr);
        orderRequest.setSign(dto.getSignType());
        orderRequest.setSign(sign);
        orderRequest.setDeviceInfo("");
        orderRequest.setBody(CodeUtils.urlEncode(dto.getBody()));
        orderRequest.setOutTradeNo(dto.getOrderCode());
        orderRequest.setTotalFee(Integer.parseInt(dto.getPayAmount()));
        orderRequest.setSpbillCreateIp(dto.getClientIp());
        orderRequest.setNotifyUrl(this.getNotifyUrl(Constants.Keys.WEIXIN_NOTIFY_URL));
        orderRequest.setTradeType(Constants.TradeType.H5_TRADE_TYPE);
        orderRequest.setSceneInfo(JSON.toJSONString(sceneInfo));

        return client.payOrder(orderRequest);
    }

    @Override
    public Response payApp(PayDto dto) {
        log.info("微信APP支付，入参 = {}",dto);
        WeiXinOrderRequest orderRequest = new WeiXinOrderRequest();
        PayChannel payChannel = this.queryCurrentPayChannel(dto.getPayType());

        if (ObjectUtils.isEmpty(payChannel)) {
            return new Response(RespConstants.UNKNOWN_CHANNEL.code,RespConstants.UNKNOWN_CHANNEL.msg);
        }

        String nonceStr = UUID.randomUUID().toString();

        // 生成微信H5支付签名
        String sign = generateSign(payChannel,dto,nonceStr,Constants.TradeType.H5_TRADE_TYPE,"",null);

        orderRequest.setAppId(payChannel.getAppId());
        orderRequest.setMchId(payChannel.getMchId());
        orderRequest.setNonceStr(nonceStr);
        orderRequest.setSign(dto.getSignType());
        orderRequest.setSign(sign);
        orderRequest.setDeviceInfo("WEB");
        orderRequest.setBody(CodeUtils.urlEncode(dto.getBody()));
        orderRequest.setOutTradeNo(dto.getOrderCode());
        orderRequest.setTotalFee(Integer.parseInt(dto.getPayAmount()));
        orderRequest.setSpbillCreateIp(dto.getClientIp());
        orderRequest.setNotifyUrl(this.getNotifyUrl(Constants.Keys.WEIXIN_NOTIFY_URL));
        orderRequest.setTradeType(Constants.TradeType.APP_TRADE_TYPE);

        return client.payOrder(orderRequest);
    }

    @Override
    public Response payPublicNumber(PayDto dto) {
        log.info("微信公众号支付，入参 = {}",dto);
        WeiXinOrderRequest orderRequest = new WeiXinOrderRequest();
        PayChannel payChannel = this.queryCurrentPayChannel(dto.getPayType());

        if (ObjectUtils.isEmpty(payChannel)) {
            return new Response(RespConstants.UNKNOWN_CHANNEL.code,RespConstants.UNKNOWN_CHANNEL.msg);
        }

        String nonceStr = UUID.randomUUID().toString();

        // 生成微信支付签名
        String sign = generateSign(payChannel,dto,nonceStr,Constants.TradeType.H5_TRADE_TYPE,"",null);

        orderRequest.setAppId(payChannel.getAppId());
        orderRequest.setMchId(payChannel.getMchId());
        orderRequest.setNonceStr(nonceStr);
        orderRequest.setSign(dto.getSignType());
        orderRequest.setSign(sign);
        orderRequest.setDeviceInfo("WEB");
        orderRequest.setBody(CodeUtils.urlEncode(dto.getBody()));
        orderRequest.setOutTradeNo(dto.getOrderCode());
        orderRequest.setTotalFee(Integer.parseInt(dto.getPayAmount()));
        orderRequest.setSpbillCreateIp(dto.getClientIp());
        orderRequest.setNotifyUrl(this.getNotifyUrl(Constants.Keys.WEIXIN_NOTIFY_URL));
        orderRequest.setTradeType(Constants.TradeType.JSAPI_TRADE_TYPE);

        return client.payOrder(orderRequest);
    }

    @Override
    public Response payScan(PayDto dto) {
        log.info("微信扫码支付，入参 = {}",dto);
        WeiXinOrderRequest orderRequest = new WeiXinOrderRequest();
        PayChannel payChannel = this.queryCurrentPayChannel(dto.getPayType());

        if (ObjectUtils.isEmpty(payChannel)) {
            return new Response(RespConstants.UNKNOWN_CHANNEL.code,RespConstants.UNKNOWN_CHANNEL.msg);
        }

        String nonceStr = UUID.randomUUID().toString();

        // 生成微信支付签名
        String sign = generateSign(payChannel,dto,nonceStr,Constants.TradeType.H5_TRADE_TYPE,"",null);

        orderRequest.setAppId(payChannel.getAppId());
        orderRequest.setMchId(payChannel.getMchId());
        orderRequest.setNonceStr(nonceStr);
        orderRequest.setSign(dto.getSignType());
        orderRequest.setSign(sign);
        orderRequest.setDeviceInfo("WEB");
        orderRequest.setBody(CodeUtils.urlEncode(dto.getBody()));
        orderRequest.setOutTradeNo(dto.getOrderCode());
        orderRequest.setTotalFee(Integer.parseInt(dto.getPayAmount()));
        orderRequest.setSpbillCreateIp(dto.getClientIp());
        orderRequest.setNotifyUrl(this.getNotifyUrl(Constants.Keys.WEIXIN_NOTIFY_URL));
        orderRequest.setTradeType(Constants.TradeType.NATIVE_TRADE_TYPE);

        return client.payOrder(orderRequest);
    }


    /**
     * 生成签名
     * @param payChannel 支付渠道
     * @param nonceStr 支付随机key
     * @param dto 支付主体入参对象
     */
    private String generateSign(PayChannel payChannel,PayDto dto,String nonceStr,String tradeType,String openId,String sceneInfo){
        // 我们自己平台与微信支付对接
        Map<String,String> post = Maps.newConcurrentMap();
        post.put("appid",payChannel.getAppId());
        post.put("mch_id",payChannel.getMchId());
        post.put("nonce_str",nonceStr);
        post.put("sign_type",Constants.SignType.MD5.name());

        post.put("device_info","");
        post.put("body",CodeUtils.urlDecode(dto.getBody()));
        post.put("out_trade_no",dto.getOrderCode());
        post.put("total_fee",dto.getPayAmount());
        post.put("spbill_create_ip",dto.getClientIp());
        post.put("notify_url","");
        post.put("trade_type",tradeType);
        post.put("openid",openId);
        post.put("scene_info",sceneInfo);
        // 生成微信H5支付签名
        return SignUtils.handleSign(post,nonceStr,Constants.SignType.MD5.name());
    }

    static class SceneInfo implements Serializable{
        private SceneInfoContent h5_info;

        public SceneInfoContent getH5_info() {
            return h5_info;
        }

        public void setH5_info(SceneInfoContent h5_info) {
            this.h5_info = h5_info;
        }
    }

    static class SceneInfoContent implements Serializable {
        private String type;

        private String wap_url;

        private String wap_name;

        private String app_name;

        private String bundle_id;

        private String package_name;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getWap_url() {
            return wap_url;
        }

        public void setWap_url(String wap_url) {
            this.wap_url = wap_url;
        }

        public String getWap_name() {
            return wap_name;
        }

        public void setWap_name(String wap_name) {
            this.wap_name = wap_name;
        }

        public String getApp_name() {
            return app_name;
        }

        public void setApp_name(String app_name) {
            this.app_name = app_name;
        }

        public String getBundle_id() {
            return bundle_id;
        }

        public void setBundle_id(String bundle_id) {
            this.bundle_id = bundle_id;
        }

        public String getPackage_name() {
            return package_name;
        }

        public void setPackage_name(String package_name) {
            this.package_name = package_name;
        }
    }
}
