package quick.pager.pay.service.pay;

import quick.pager.common.resp.Response;
import quick.pager.pay.dto.PayDto;

/**
 * 支付宝支付
 */
public interface AlipayService {
    /**
     * H5支付
     */
    Response payH5(PayDto dto);

    /**
     * app支付
     */
    Response payApp(PayDto dto);

    /**
     * web网页支付
     */
    Response payWeb(PayDto dto);

    /**
     * 扫码支付
     */
    Response payScan(PayDto dto);

}
