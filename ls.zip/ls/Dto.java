package quick.pager.pay.dto;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class Dto implements Serializable {

    /**
     * 商户号
     */
    private String merchantNo;
    /**
     * 商户订单号
     */
    private String merchantOrderNo;
    /**
     * 支付方式
     */
    private String payType;
    /**
     * 支付金额(单位是分)
     */
    private String payAmount;
    /**
     * 支付主题内容
     */
    private String body;
    /**
     * 回调地址
     */
    private String notifyUrl;
    /**
     * 支付商户的签名
     */
    private String sign;
    /**
     * 签名加密方式<br />
     * MD5<br />
     * AES<br />
     */
    private String signType;
}
