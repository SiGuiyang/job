package quick.pager.pay.app.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import quick.pager.common.constants.Constants;
import quick.pager.common.constants.RespConstants;
import quick.pager.common.resp.Response;
import quick.pager.pay.request.SubmitWeiXinRequest;
import quick.pager.pay.service.pay.PayService;

/**
 * 微信支付
 */
@Controller
@RequestMapping(Constants.PAY_MODULE)
public class WeiXinPayController {

    @Reference(interfaceClass = PayService.class)
    private PayService payService;

    /**
     * 支付
     *
     * @param request 请求主体
     */
    @PostMapping("/weixin/submit")
    public Response pay(SubmitWeiXinRequest request) {
        
        Response verifyResponse = verifyParams(request);
        if (RespConstants.SUCCESS.code != verifyResponse.getCode()) {
            return verifyResponse;
        }

        return payService.submitOrder(request);
    }


    /**
     * 验证入参
     */
    private Response verifyParams(SubmitWeiXinRequest request) {
        if (ObjectUtils.isEmpty(request)) {
            return new Response(RespConstants.PARAMETER_ERROR.code, RespConstants.PARAMETER_ERROR.msg);
        }
        if (StringUtils.isEmpty(request.getMerchantOrderNo())) {
            return new Response(RespConstants.MERCHANT_ORDER_CODE_NOT_BANK.code, RespConstants.MERCHANT_ORDER_CODE_NOT_BANK.msg);
        }
        if (StringUtils.isEmpty(request.getMerchantNo())) {
            return new Response(RespConstants.MERCHANT_NOT_BLANK.code,RespConstants.MERCHANT_NOT_BLANK.msg);
        }

        if (StringUtils.isEmpty(request.getNotifyUrl())) {
            return new Response(RespConstants.NOTIFY_URL_NOT_BLANK.code,RespConstants.NOTIFY_URL_NOT_BLANK.msg);
        }

        if (StringUtils.isEmpty(request.getPayAmount())) {
            return new Response(RespConstants.PAY_AMOUNT_NOT_BLANK.code,RespConstants.PAY_AMOUNT_NOT_BLANK.msg);
        }

        if (StringUtils.isEmpty(request.getPayType())) {
            return new Response(RespConstants.PAY_TYPE_NOT_BLANK.code,RespConstants.PAY_TYPE_NOT_BLANK.msg);
        }

        if (StringUtils.isEmpty(request.getClientIp())) {
            return new Response(RespConstants.CLIENT_IP_NOT_BLANK.code,RespConstants.CLIENT_IP_NOT_BLANK.msg);
        }

        if (StringUtils.isEmpty(request.getBody())) {
            return new Response(RespConstants.PAY_BODY_NOT_BLANK.code,RespConstants.PAY_BODY_NOT_BLANK.msg);
        }

        if (StringUtils.isEmpty(request.getSign())) {
            return new Response(RespConstants.PAY_SIGN_NOT_BLANK.code,RespConstants.PAY_SIGN_NOT_BLANK.msg);
        }
        return new Response();
    }

    /**
     * 退款
     *
     * @param request 请求主体
     */
    @PostMapping("/weixin/refund")
    public String refund(SubmitWeiXinRequest request) {
        return "";
    }

    /**
     * 查询退款订单
     *
     * @param request 请求主体
     */
    @PostMapping("/weixin/refund/query/")
    public String refundQuery(SubmitWeiXinRequest request) {
        return "";
    }

    /**
     * 查询订单
     *
     * @param request 请求主体
     */
    @PostMapping("/weixin/query")
    public String queryOrder(SubmitWeiXinRequest request) {
        return "";
    }
}
