package quick.pager.pay.service.repository.pay;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import quick.pager.pay.mapper.PayChannelCenterMapper;
import quick.pager.pay.mapper.PayChannelMapper;
import quick.pager.pay.mapper.SystemConfigMapper;
import quick.pager.pay.model.PayChannel;
import quick.pager.pay.model.PayChannelCenter;
import quick.pager.pay.model.SystemConfig;
import quick.pager.pay.service.pay.BaseService;

@Service
public class BaseServiceImpl implements BaseService {
    @Autowired
    private PayChannelCenterMapper payChannelCenterMapper;
    @Autowired
    private PayChannelMapper payChannelMapper;
    @Autowired
    private SystemConfigMapper systemConfigMapper;

    @Override
    public PayChannelCenter queryCurrentPayChannelCenter() {

        return payChannelCenterMapper.selectPayChannelCenterEnable();
    }

    @Override
    public PayChannel queryCurrentPayChannel(String payType) {

        PayChannelCenter payChannelCenter = this.queryCurrentPayChannelCenter();

        if (ObjectUtils.isEmpty(payChannelCenter)){
            return null;
        }

        return payChannelMapper.selectPayChannelEnable(payChannelCenter.getId(),payType);
    }

    /**
     * 根据配置项查询回调地址
     * @param configName 配置项名称
     */
    String getNotifyUrl(String configName) {
        SystemConfig systemConfig = systemConfigMapper.selectSystemConfigByConfigName(configName);
        if (ObjectUtils.isEmpty(systemConfig)) {
            return "";
        }
        return systemConfig.getConfigValue();
    }
}
