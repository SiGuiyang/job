package quick.pager.common.pay.client;

import quick.pager.common.constants.Constants;
import quick.pager.common.constants.RespConstants;
import quick.pager.common.pay.request.WeiXinCloseOrderRequest;
import quick.pager.common.pay.request.WeiXinOrderRequest;
import quick.pager.common.pay.request.WeiXinQueryOrderRequest;
import quick.pager.common.pay.request.WeiXinQueryRefundOrderRequest;
import quick.pager.common.pay.response.WeiXinCloseOrderResponse;
import quick.pager.common.pay.response.WeiXinPayOrderResponse;
import quick.pager.common.pay.response.WeiXinQueryOrderResponse;
import quick.pager.common.pay.response.WeiXinQueryRefundOrderResponse;
import quick.pager.common.resp.Response;
/**
 * 微信支付
 */
public class WeiXinPayClient extends BasePayClient {

    @Override
    public Response payOrder(IRequest request) {
        Response resp = new Response();

        if (request instanceof WeiXinOrderRequest) {
            WeiXinOrderRequest orderRequest = (WeiXinOrderRequest) request;
            resp.setData(this.execute(orderRequest, Constants.PayURL.WEIXIN_PAY_URL, new WeiXinPayOrderResponse()));
        } else {
            resp.setCode(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.msg);
        }
        return resp;
    }

    @Override
    public Response closeOrder(IRequest request) {
        Response resp = new Response();
        if (request instanceof WeiXinCloseOrderRequest) {
            WeiXinCloseOrderRequest closeOrderRequest = (WeiXinCloseOrderRequest) request;
            resp.setData(this.execute(closeOrderRequest, Constants.PayURL.WEIXIN_CLOSE_URL, new WeiXinCloseOrderResponse()));
        } else {
            resp.setCode(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.msg);
        }


        return resp;
    }

    @Override
    public Response refundOrder(IRequest request) {


        return null;
    }

    @Override
    public Response queryPayOrder(IRequest request) {
        Response resp = new Response();

        if (request instanceof WeiXinQueryOrderRequest) {
            WeiXinQueryOrderRequest queryOrderRequest = (WeiXinQueryOrderRequest) request;
            resp.setData(this.execute(queryOrderRequest, Constants.PayURL.WEIXIN_QUERY_URL, new WeiXinQueryOrderResponse()));
        } else {
            resp.setCode(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.msg);
        }

        return resp;
    }

    @Override
    public Response queryRefundOrder(IRequest request) {
        Response resp = new Response();

        if (request instanceof WeiXinQueryRefundOrderRequest) {
            WeiXinQueryRefundOrderRequest queryRefundOrderRequest = (WeiXinQueryRefundOrderRequest) request;
            resp.setData(this.execute(queryRefundOrderRequest, Constants.PayURL.WEIXIN_QUERY_REFUND_URL, new WeiXinQueryRefundOrderResponse()));
        } else {
            resp.setCode(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.code);
            resp.setMsg(RespConstants.WEIXIN_REQUEST_TYPE_EXCEPTION.msg);
        }

        return resp;
    }

    @Override
    public Response wapPay(IRequest request) {
        return null;
    }

    @Override
    public Response appPay(IRequest request) {
        return null;
    }

    @Override
    public Response webPay(IRequest request) {
        return null;
    }
}
