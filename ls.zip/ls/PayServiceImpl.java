package quick.pager.pay.service.repository.pay;

import com.alibaba.dubbo.config.annotation.Service;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import quick.pager.common.constants.Constants;
import quick.pager.common.constants.RespConstants;
import quick.pager.common.resp.Response;
import quick.pager.common.utils.GenerateUtils;
import quick.pager.common.utils.SignUtils;
import quick.pager.pay.dto.PayDto;
import quick.pager.pay.mapper.MerchantMapper;
import quick.pager.pay.mapper.form.OrderMapper;
import quick.pager.pay.model.Merchant;
import quick.pager.pay.model.form.Order;
import quick.pager.pay.request.PayRequest;
import quick.pager.pay.request.SubmitAlipayRequest;
import quick.pager.pay.request.SubmitWeiXinRequest;
import quick.pager.pay.service.pay.AlipayService;
import quick.pager.pay.service.pay.PayService;
import quick.pager.pay.service.pay.WeiXinService;

import java.math.BigDecimal;
import java.util.Map;

/**
 * 支付服务
 */
@Service(interfaceClass = PayService.class)
@Component
@Slf4j
public class PayServiceImpl implements PayService {

    @Autowired
    private MerchantMapper merchantMapper;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private AlipayService alipayService;
    @Autowired
    private WeiXinService weiXinService;

    @Override
    public Response submitOrder(PayRequest request) {

        String payType = request.getPayType();
        String merchantNo = request.getMerchantNo();
        String sign = request.getSign();
        String clientIp = "";
        String jumpUrl = "";
        boolean weChatPay = payType.startsWith(Constants.WECHAT_PREFIX);
        // 入参组装，准备验签
        Map<String, String> postparams = Maps.newConcurrentMap();
        postparams.put("merchant_no", merchantNo);
        postparams.put("merchant_order_no", request.getMerchantOrderNo());
        postparams.put("body", request.getBody());
        postparams.put("pay_amount", request.getPayAmount());
        postparams.put("notify_url", request.getNotifyUrl());
        if (weChatPay) {
            SubmitWeiXinRequest submitWeiXinRequest = (SubmitWeiXinRequest) request;
            clientIp = submitWeiXinRequest.getClientIp();
            jumpUrl = submitWeiXinRequest.getJumpUrl();
            postparams.put("client_ip", clientIp);
            postparams.put("jump_url", jumpUrl);
        }

        // 查询商户
        Merchant merchant = merchantMapper.selectMerchantByMerchantNo(merchantNo);

        if (ObjectUtils.isEmpty(merchant)) {
            return new Response(RespConstants.UNKNOWN_MERCHANT.code, RespConstants.UNKNOWN_MERCHANT.msg);
        }

        String plateSign = SignUtils.handleSign(postparams, merchant.getPublicKey(), request.getSignType());

        log.info("平台处理的签名 sign = {}", plateSign);

        if (!sign.equals(plateSign)) {
            log.warn("验证签名不通过");
            return new Response(RespConstants.VERIFY_SIGN_NOT_EQUALS.code,RespConstants.VERIFY_SIGN_NOT_EQUALS.msg);
        }

        log.info("支付验证签名通过");

        // 验签成功创建预订单
        Order order = new Order();
        order.setMerchantNo(merchantNo);
        order.setMerchantOrderCode(request.getMerchantOrderNo());
        order.setNotifyUrl(request.getNotifyUrl());
        order.setPayAmount(new BigDecimal(request.getPayAmount()));
        order.setOrderCode(GenerateUtils.generateCode());
        order.setTradeCode(GenerateUtils.generateTradeCode());
        order.setPayType(request.getPayType());
        order.setPayStatus(Constants.PayStatus.created);
        order.setNotificationStatus(Constants.NotificationStatus.publish);
        order.setPayClientId(clientIp);
        order.setPayJumpUrl(jumpUrl);
        // 支付订单插入数据
        orderMapper.insertSelective(order);

        // 数据传值
        PayDto dto = createPayDto(request,clientIp,jumpUrl,order.getOrderCode());

        // 微信支付
        if (weChatPay) {
            log.info("微信支付流程");
            return this.payOrderWeChatPay(dto);
        } else {
            log.info("支付宝支付流程");
            return this.payOrderAlipay(dto);
        }
    }

    /**
     * 数据转换
     * @param request 请求对象
     * @param clientIp 客户端Ip
     * @param jumpUrl 跳转地址
     * @param orderCode 平台订单号
     */
    private PayDto createPayDto(PayRequest request, String clientIp, String jumpUrl,String orderCode) {
        PayDto dto = new PayDto();
        dto.setClientIp(clientIp);
        dto.setJumpUrl(jumpUrl);
        dto.setBody(request.getBody());
        dto.setMerchantNo(request.getMerchantNo());
        dto.setMerchantOrderNo(request.getMerchantOrderNo());
        dto.setNotifyUrl(request.getNotifyUrl());
        dto.setPayAmount(request.getPayAmount());
        dto.setPayType(request.getPayType());
        dto.setOrderCode(orderCode);
        return dto;
    }


    @Override
    public Response payOrderAlipay(PayDto dto) {
        log.info("支付宝开始选择支付方式，走不同的支付流程");
        Response resp = null;
        switch (dto.getPayType()) {
            case Constants.PayType.AlIPAY_APP:
                resp = alipayService.payApp(dto);
                break;
            case Constants.PayType.ALIPAY_H5:
                resp = alipayService.payH5(dto);
                break;
            case Constants.PayType.ALIPAY_SCAN_QR:
                resp = alipayService.payScan(dto);
                break;
            case Constants.PayType.ALIPAY_WEB:
                resp = alipayService.payWeb(dto);
                break;
        }
        return resp;
    }

    @Override
    public Response payOrderWeChatPay(PayDto dto) {
        log.info("微信开始选择支付方式，走不同的支付流程");
        Response resp = null;
        switch (dto.getPayType()) {
            case Constants.PayType.WECHAT_APP:
                resp = weiXinService.payApp(dto);
                break;
            case Constants.PayType.WECHAT_H5:
                resp = weiXinService.payH5(dto);
                break;
            case Constants.PayType.WECHAT_PUBLIC_NUMBER:
                resp = weiXinService.payPublicNumber(dto);
                break;
            case Constants.PayType.WECHAT_SCAN_QR:
                resp = weiXinService.payScan(dto);
                break;
        }
        return resp;
    }
}
