package quick.pager.pay.service.pay;

import quick.pager.common.resp.Response;
import quick.pager.pay.dto.PayDto;

/**
 * 微信支付
 */
public interface WeiXinService {

    /**
     * H5支付
     */
    Response payH5(PayDto dto);

    /**
     * app支付
     */
    Response payApp(PayDto dto);

    /**
     * 公众号支付
     */
    Response payPublicNumber(PayDto dto);

    /**
     * 扫码支付
     */
    Response payScan(PayDto dto);
}
