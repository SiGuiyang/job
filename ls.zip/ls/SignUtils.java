package quick.pager.common.utils;

import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.digest.DigestAlgorithm;
import cn.hutool.crypto.digest.Digester;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.codec.binary.Hex;
import quick.pager.common.constants.Constants;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * 签名工具类
 */
public class SignUtils {
    // MD5 签名方式
    private static final String MD5 = "MD5";
    // AES 签名方式
    private static final String AES = "AES";
    // HMAC-SHA256签名方式
    private static final String  SHA256 = "HmacSHA256";
    // AES 加密的key
    private static final String AES_KEY = "PagePay";

    /**
     * map中的key按照字典顺序排序
     * 参数名ASCII字典序排序
     * @param params    参数
     * @param secretKey 密钥
     * @param signType  签名类型
     * @return 加密后的文件
     */
    public static String handleSign(Map<String, String> params, String secretKey, String signType) {

        if (null == params || 0 == params.size()) {
            return null;
        }
        List<String> keys = Lists.newArrayList();
        params.forEach((key, value) -> {
            keys.add(key);
        });

        Collections.sort(keys);
        StringBuilder builder = new StringBuilder();
        keys.forEach(key->
            builder.append(key).append("=").append(params.get(key)).append("&")
        );

        builder.append("key").append("=").append(secretKey);
        if (MD5.equals(signType)) {
            return SecureUtil.md5(builder.toString()).toUpperCase();
        } else if (AES.equals(signType)){

            return new String(SecureUtil.aes(AES_KEY.getBytes()).encrypt(builder.toString())).toUpperCase();
        } else if (SHA256.equals(signType)) {
            String result = hmacSHA256(builder.toString(),secretKey);
            if(!StrUtil.isBlank(result)) {
                return result.toUpperCase();
            }
        }
        return null;
    }

    /**
     * hmacSHA256 加密
     */
    private static String hmacSHA256(String data,String key) {
        Mac sha256;
        try {
            sha256 = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(), "HmacSHA256");
            sha256.init(secretKeySpec);
            byte[] bytes = sha256.doFinal(data.getBytes());
            return Hex.encodeHexString(bytes);
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args){
        String secretKey = "192006250b4c09247ec02edce69f6a2d";
        Map<String,String> params = Maps.newConcurrentMap();
        params.put("device_info","1000");
        params.put("body","test");
        params.put("appid","wxd930ea5d5a258f4f");
        params.put("nonce_str","ibuaiVcKdpRxkhJA");
        params.put("mch_id","10000100");
        String sign = handleSign(params,secretKey,Constants.SignType.HmacSHA256.name());
        System.out.println(sign);
        String successSign = "6A9AE1657590FD6257D693A078E1C3E4BB6BA4DC30B23E0EE2496E54170DACD6";
        System.out.println(sign.equals(successSign));

    }
}
