package quick.pager.pay.service.pay;

import quick.pager.pay.model.PayChannel;
import quick.pager.pay.model.PayChannelCenter;

/**
 * 通用业务流程处理
 */
public interface BaseService  {
    /**
     * 选择当前可用的支付中心
     */
    PayChannelCenter queryCurrentPayChannelCenter();

    /**
     * 支付方式选择当前可用的支付渠道
     * @param payType 支付方式
     */
    PayChannel queryCurrentPayChannel(String payType);
}
